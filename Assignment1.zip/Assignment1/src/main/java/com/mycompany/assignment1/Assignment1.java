/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment1;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Assignment1 {

    private static final HospitalSystem system = new HospitalSystem();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            displayMenu();
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1 -> registerPatient();
                case 2 -> searchPatient();
                case 3 -> updatePatient();
                case 4 -> deletePatient();
                case 5 -> system.displayAllPatients();
                case 6 -> allocateBed();
                case 7 -> releaseBed();
                case 8 -> system.displayWardLayout();
                case 9 -> displayAvailableBeds();
                case 10 -> displayOccupiedBeds();
                case 11 -> displayReports();
                case 0 -> {
                    System.out.println("Exiting system. Goodbye!");
                    exit = true;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("===== Netcare Hospital Patient Admission System =====");
        System.out.println("1. Register Patient");
        System.out.println("2. Search Patient by ID");
        System.out.println("3. Update Patient Details");
        System.out.println("4. Delete Patient");
        System.out.println("5. Display All Patients");
        System.out.println("6. Allocate Bed to Inpatient");
        System.out.println("7. Release Bed");
        System.out.println("8. Display Ward Layout");
        System.out.println("9. Display Available Beds");
        System.out.println("10. Display Occupied Beds");
        System.out.println("11. View Report");
        System.out.println("0. Exit");
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = scanner.nextInt();
                scanner.nextLine(); // consume leftover newline
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // clear invalid token
            }
        }
    }

    private static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    // ----------- Menu Actions --------------

    private static void registerPatient() {
        try {
            String id = readString("Enter Patient ID: ");
            String firstName = readString("First Name: ");
            String lastName = readString("Last Name: ");
            int age = readInt("Age: ");
            String gender = readString("Gender (Female/Male): ");
            String condition = readString("Medical Condition: ");
            String categoryInput = readString("Category (INPATIENT/OUTPATIENT/EMERGENCY): ");
            PatientCategory category = PatientCategory.valueOf(categoryInput.toUpperCase());

            Patient patient;
            if (category == PatientCategory.INPATIENT) {
                // For inpatient, bed is allocated later; bed and ward start as null
                patient = new Inpatient(id, firstName, lastName, age, gender, condition, null, null);
            } else {
                patient = new Patient(id, firstName, lastName, age, gender, condition, category);
            }
            system.registerPatient(patient);
            System.out.println("Patient registered successfully.");
            if (category == PatientCategory.INPATIENT) {
                System.out.println("Remember to allocate a bed using option 6.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void searchPatient() {
        String id = readString("Enter Patient ID to search: ");
        Patient p = system.searchPatient(id);
        if (p == null) {
            System.out.println("Patient not found.");
        } else {
            p.displayDetails();
        }
    }

    private static void updatePatient() {
        try {
            String id = readString("Enter Patient ID to update: ");
            String firstName = readString("New First Name: ");
            String lastName = readString("New Last Name: ");
            int age = readInt("New Age: ");
            String gender = readString("New Gender (Female/Male): ");
            String condition = readString("New Medical Condition: ");
            system.updatePatient(id, firstName, lastName, age, gender, condition);
            System.out.println("Patient updated successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deletePatient() {
        String id = readString("Enter Patient ID to delete: ");
        try {
            system.deletePatient(id);
            System.out.println("Patient deleted successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void allocateBed() {
        String id = readString("Enter Patient ID (must be inpatient): ");
        try {
            system.allocateBed(id);
            System.out.println("Bed allocated successfully.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void releaseBed() {
        String bed = readString("Enter Bed Number (e.g., B05): ");
        try {
            system.releaseBed(bed);
            System.out.println("Bed released successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void displayAvailableBeds() {
        System.out.println("Available beds: " + system.getAvailableBeds());
    }

    private static void displayOccupiedBeds() {
        System.out.println("Occupied beds: " + system.getOccupiedBeds());
    }

    private static void displayReports() {
        System.out.println("\n===== Reports =====");
        System.out.println("Total registered patients: " + system.getTotalPatients());
        System.out.println("Total occupied beds: " + system.getTotalOccupiedBeds());
        System.out.printf("Ward occupancy: %.2f%%%n", system.getOccupancyPercentage());
        System.out.println("\nAll patients:");
        system.displayAllPatients();
        System.out.println("\nAvailable beds: " + system.getAvailableBeds());
        System.out.println("Occupied beds: " + system.getOccupiedBeds());
    }

    // ----------- Supporting Classes --------------

    private enum PatientCategory {
        INPATIENT, OUTPATIENT, EMERGENCY
    }

    private static class Patient {
        private final String id;
        private String firstName;
        private String lastName;
        private int age;
        private String gender;
        private String condition;
        private final PatientCategory category;

        
        //Constructors 
        public Patient(String id, String firstName, String lastName, int age,
                       String gender, String condition, PatientCategory category) {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            this.gender = gender;
            this.condition = condition;
            this.category = category;
        }

        //Getters and setters
        public String getId() { return id; }
        public String getFirstName() { return firstName; }
        public PatientCategory getCategory() { return category; }

        public void setFirstName(String firstName) { this.firstName = firstName; }
        public void setLastName(String lastName) { this.lastName = lastName; }
        public void setAge(int age) { this.age = age; }
        public void setGender(String gender) { this.gender = gender; }
        public void setCondition(String condition) { this.condition = condition; }

        public void displayDetails() {
            System.out.println("Patient ID: " + id);
            System.out.println("Name: " + firstName + " " + lastName);
            System.out.println("Age: " + age);
            System.out.println("Gender: " + gender);
            System.out.println("Condition: " + condition);
            System.out.println("Category: " + category);
        }
    }

    private static class Inpatient extends Patient {
        private String bedNumber;
        private String ward;

        public Inpatient(String id, String firstName, String lastName, int age,
                         String gender, String condition, String bedNumber, String ward) {
            super(id, firstName, lastName, age, gender, condition, PatientCategory.INPATIENT);
            this.bedNumber = bedNumber;
            this.ward = ward;
        }

        public String getBedNumber() { return bedNumber; }
        public void setBedNumber(String bedNumber) { this.bedNumber = bedNumber; }
        public void setWard(String ward) { this.ward = ward; }

        @Override
        public void displayDetails() {
            super.displayDetails();
            System.out.println("Bed Number: " + (bedNumber == null ? "Not allocated" : bedNumber));
        }
    }

    private static class HospitalSystem {
        private static final int ROWS = 4;
        private static final int COLS = 5;

        private final List<Patient> patients = new ArrayList<>();
        // 2D array representing the ward layout; each cell holds the occupying patient's ID, or null if free
        private final String[][] beds = new String[ROWS][COLS];

        public void registerPatient(Patient patient) {
            if (searchPatient(patient.getId()) != null) {
                throw new IllegalArgumentException("A patient with this ID already exists.");
            }
            patients.add(patient);
        }

        public Patient searchPatient(String id) {
            for (Patient p : patients) {
                if (p.getId().equalsIgnoreCase(id)) {
                    return p;
                }
            }
            return null;
        }

        public void updatePatient(String id, String firstName, String lastName,
                                   int age, String gender, String condition) {
            Patient p = searchPatient(id);
            if (p == null) {
                throw new IllegalArgumentException("Patient not found.");
            }
            p.setFirstName(firstName);
            p.setLastName(lastName);
            p.setAge(age);
            p.setGender(gender);
            p.setCondition(condition);
        }

        public void deletePatient(String id) {
            Patient p = searchPatient(id);
            if (p == null) {
                throw new IllegalArgumentException("Patient not found.");
            }
            if (p instanceof Inpatient inpatient && inpatient.getBedNumber() != null) {
                releaseBed(inpatient.getBedNumber());
            }
            patients.remove(p);
        }

        public void displayAllPatients() {
            if (patients.isEmpty()) {
                System.out.println("No patients registered.");
                return;
            }
            Patient[] sorted = patients.toArray(new Patient[0]);
            sortPatientsById(sorted);
            for (Patient p : sorted) {
                p.displayDetails();
                System.out.println("-----------------------------");
            }
        }

        // Simple bubble sort - demonstrates sorting an array and passing an array to a method
        private void sortPatientsById(Patient[] arr) {
            for (int i = 0; i < arr.length - 1; i++) {
                for (int j = 0; j < arr.length - 1 - i; j++) {
                    if (arr[j].getId().compareToIgnoreCase(arr[j + 1].getId()) > 0) {
                        Patient temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
        }

        public void allocateBed(String id) {
            Patient p = searchPatient(id);
            if (p == null) {
                throw new IllegalArgumentException("Patient not found.");
            }
            if (!(p instanceof Inpatient inpatient)) {
                throw new IllegalArgumentException("Only inpatients may be allocated a bed.");
            }
            if (inpatient.getBedNumber() != null) {
                throw new IllegalStateException("Patient already has a bed allocated.");
            }
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    if (beds[r][c] == null) {
                        beds[r][c] = id;
                        inpatient.setBedNumber(bedLabel(r, c));
                        return;
                    }
                }
            }
            throw new IllegalStateException("No beds available.");
        }

        public void releaseBed(String bedNumber) {
            int[] coords = bedCoordinates(bedNumber);
            if (coords == null) {
                throw new IllegalArgumentException("Invalid bed number.");
            }
            int r = coords[0], c = coords[1];
            if (beds[r][c] == null) {
                throw new IllegalArgumentException("This bed is already free.");
            }
            Patient p = searchPatient(beds[r][c]);
            if (p instanceof Inpatient inpatient) {
                inpatient.setBedNumber(null);
            }
            beds[r][c] = null;
        }

        public void displayWardLayout() {
            System.out.println("\n===== Ward Layout (4 x 5) =====");
            for (int r = 0; r < ROWS; r++) {
                StringBuilder row = new StringBuilder();
                for (int c = 0; c < COLS; c++) {
                    String label = bedLabel(r, c);
                    String status = beds[r][c] == null ? "[Free ]" : "[" + beds[r][c] + "]";
                    row.append(label).append(status).append("  ");
                }
                System.out.println(row.toString().trim());
            }
        }

        public String getAvailableBeds() {
            StringBuilder sb = new StringBuilder();
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    if (beds[r][c] == null) {
                        sb.append(bedLabel(r, c)).append(" ");
                    }
                }
            }
            return sb.length() == 0 ? "None" : sb.toString().trim();
        }

        public String getOccupiedBeds() {
            StringBuilder sb = new StringBuilder();
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    if (beds[r][c] != null) {
                        sb.append(bedLabel(r, c)).append(" ");
                    }
                }
            }
            return sb.length() == 0 ? "None" : sb.toString().trim();
        }

        public int getTotalPatients() {
            return patients.size();
        }

        public int getTotalOccupiedBeds() {
            int count = 0;
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    if (beds[r][c] != null) count++;
                }
            }
            return count;
        }

        public double getOccupancyPercentage() {
            return (getTotalOccupiedBeds() / (double) (ROWS * COLS)) * 100;
        }

        private String bedLabel(int r, int c) {
            int number = r * COLS + c + 1;
            return String.format("B%02d", number);
        }

        private int[] bedCoordinates(String bedNumber) {
            if (bedNumber == null || !bedNumber.matches("(?i)B\\d{2}")) {
                return null;
            }
            int number = Integer.parseInt(bedNumber.substring(1));
            if (number < 1 || number > ROWS * COLS) {
                return null;
            }
            int index = number - 1;
            return new int[]{index / COLS, index % COLS};
        }
    }
}    
