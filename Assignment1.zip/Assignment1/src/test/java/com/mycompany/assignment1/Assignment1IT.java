/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.assignment1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author user
 */
public class HospitalSystemTest {
    
    private HospitalSystem system;
    
    
    @BeforeEach
    public void setUp() {
         system = new HospitalSystem();
    }
    
    // -------- Patient management --------
    
    @Test
    void registerPatient addsPatient() {
        Patient p = new Patient("P", "Jane", "Doe", 30, "Female", "Flu", PatientCategory.OUTPATIENT);
        system.registerPatient(p);
        
        assertEquals(1, system.getTotalPatients());
        assertSame(p, system.searchPatient("P1"));
    }
    
     @Test
    void registerPatient_duplicateId_throwsException() {
        system.registerPatient(new Patient("P1", "Jane", "Doe", 30, "Female", "Flu", PatientCategory.OUTPATIENT));

        Patient duplicate = new Patient("P1", "John", "Smith", 40, "Male", "Cold", PatientCategory.OUTPATIENT);
        assertThrows(IllegalArgumentException.class, () -> system.registerPatient(duplicate));
    }

    @Test
    void searchPatient_notFound_returnsNull() {
        assertNull(system.searchPatient("MISSING"));
    }

    @Test
    void updatePatient_updatesFields() {
        system.registerPatient(new Patient("P1", "Jane", "Doe", 30, "Female", "Flu", PatientCategory.OUTPATIENT));

        system.updatePatient("P1", "Janet", "Doe", 31, "Female", "Recovered");

        Patient updated = system.searchPatient("P1");
        assertEquals("Janet", updated.getFirstName());
        assertEquals(31, updated.getAge());
        assertEquals("Recovered", updated.getCondition());
    }

    @Test
    void updatePatient_notFound_throwsException() {
        assertThrows(IllegalArgumentException.class,
                () -> system.updatePatient("NOPE", "A", "B", 1, "Male", "None"));
    }

    @Test
    void deletePatient_removesPatientAndFreesBed() {
        system.registerPatient(new Inpatient("P1", "Jane", "Doe", 30, "Female", "Flu", null, null));
        system.allocateBed("P1");

        system.deletePatient("P1");

        assertNull(system.searchPatient("P1"));
        assertEquals(0, system.getTotalOccupiedBeds());
    }

    @Test
    void deletePatient_notFound_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> system.deletePatient("NOPE"));
    }

    // ---------- Bed management ----------

    @Test
    void allocateBed_toInpatient_succeeds() {
        system.registerPatient(new Inpatient("P1", "Jane", "Doe", 30, "Female", "Flu", null, null));

        system.allocateBed("P1");

        Inpatient p = (Inpatient) system.searchPatient("P1");
        assertNotNull(p.getBedNumber());
        assertEquals(1, system.getTotalOccupiedBeds());
    }

    @Test
    void allocateBed_toNonInpatient_throwsException() {
        system.registerPatient(new Patient("P1", "Jane", "Doe", 30, "Female", "Flu", PatientCategory.OUTPATIENT));

        assertThrows(IllegalArgumentException.class, () -> system.allocateBed("P1"));
    }

    @Test
    void allocateBed_whenAlreadyAllocated_throwsException() {
        system.registerPatient(new Inpatient("P1", "Jane", "Doe", 30, "Female", "Flu", null, null));
        system.allocateBed("P1");

        assertThrows(IllegalStateException.class, () -> system.allocateBed("P1"));
    }

    @Test
    void allocateBed_whenWardFull_throwsException() {
        // Fill all 20 beds
        for (int i = 1; i <= 20; i++) {
            String id = "P" + i;
            system.registerPatient(new Inpatient(id, "First" + i, "Last" + i, 20, "Male", "Observation", null, null));
            system.allocateBed(id);
        }

        // 21st inpatient should not get a bed
        system.registerPatient(new Inpatient("P21", "Extra", "Patient", 20, "Male", "Observation", null, null));
        assertThrows(IllegalStateException.class, () -> system.allocateBed("P21"));
    }

    @Test
    void releaseBed_freesTheBed() {
        system.registerPatient(new Inpatient("P1", "Jane", "Doe", 30, "Female", "Flu", null, null));
        system.allocateBed("P1");
        Inpatient p = (Inpatient) system.searchPatient("P1");
        String bedNumber = p.getBedNumber();

        system.releaseBed(bedNumber);

        assertNull(p.getBedNumber());
        assertEquals(0, system.getTotalOccupiedBeds());
    }

    @Test
    void releaseBed_invalidBedNumber_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> system.releaseBed("Z99"));
    }

    @Test
    void releaseBed_alreadyFree_throwsException() {
        assertThrows(IllegalArgumentException.class, () -> system.releaseBed("B01"));
    }

    @Test
    void getAvailableBeds_startsWithAllTwentyFree() {
        assertEquals(20, system.getAvailableBeds().split(" ").length);
        assertEquals("None", system.getOccupiedBeds());
    }

    @Test
    void occupancyPercentage_reflectsAllocatedBeds() {
        system.registerPatient(new Inpatient("P1", "Jane", "Doe", 30, "Female", "Flu", null, null));
        system.allocateBed("P1");

        assertEquals(5.0, system.getOccupancyPercentage(), 0.001); // 1 of 20 beds = 5%
    }
}
 
